window.onload = function carrinho(){
    var carrinho = document.getElementById('carrinho');
    exibirCarrinho(carrinho);
}
function addCarrinho(nome, preco, qtd, posicao){
    localStorage.setItem("nome"+posicao, nome);
    localStorage.setItem("preco"+posicao, preco);
    localStorage.setItem("qtd"+posicao, qtd);
    //preco = preco + qtd;
    console.log('nome: '+nome);
    console.log('preco: '+preco);
    console.log('quantidade: '+qtd);
}
function redirect(){
    window.location.href = 'carrinho.html';
}