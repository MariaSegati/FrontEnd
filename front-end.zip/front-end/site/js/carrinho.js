$(document).ready(function(){
function exibirCarrinho(carrinho){
    var total = 0;
    for(var i = 1; i <= 100; i++){
        if(localStorage.getItem('nome' + i) != null){ 
            let preco = 1500;
            let frete = 40;
            let qtd = parseInt(localStorage.getItem('qtd' + i));
            total += (preco * qtd) + frete;
            carrinho.innerHTML = "<table id='tabela'> <hr>"+ localStorage.getItem('nome' + i) + "<hr>"
            + localStorage.getItem('preco' + i) + "<hr>" + 'Quantidade: '+localStorage.getItem('qtd' + i)  + "<hr>" + "frete fixo: R$40" + "<hr>" + 'total: '+total+ "<hr>" + "<input type='button' class='botaozin' value='Excluir item' onclick='excluirItem("+ i +")'><br><br><a href='final.html'><button class='botaozin'>Finalizar</button></a></table>";
        }
    }
    

}
});
function excluirItem(posicao){
    /*localStorage.setItem("nome" + posicao, nome);
    localStorage.setItem("preco" + posicao, preco);
    localStorage.setItem("qtd", posicao, qtd);*/
    //console.log(nome);
    carrinho.innerHTML = '';
    //<button type="button" id="botaozin" onclick=" localStorage.clear(); location.reload();"> Limpar carrinho </button>
}