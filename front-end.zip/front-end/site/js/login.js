$(document).ready(function(){
function logar(){
    var email = document.getElementById('e-mail').value;
    var senha = document.getElementById('senha').value;
    var errorMessage = document.getElementById('msg');
    var errorMessage2 = document.getElementById('msg2');

    if(email  == '' && senha == ''){
        errorMessage.textContent = "e-mail não preenchido!"
        errorMessage.classList = 'error';
        errorMessage2.textContent = "senha não preenchido!"
        errorMessage2.classList = 'error';
        return;
    }
    if(email  == ''){
    errorMessage.textContent = "e-mail não preenchido!"
    errorMessage.classList = 'error';
    return;
    }
   if(senha  == ''){
       errorMessage2.textContent = "senha não preenchida!"
       errorMessage2.classList = 'error';
       return;
   }else if (senha.length < 4){
        errorMessage2.textContent = "mínimo 4 digitos!!"
       errorMessage2.classList = 'error';
       return;
   }
}
});
//$(document).ready(function(){
//    $('.button4').click(function(){
//        $('.button10').toggle(5000, function(){
//            alert('terminou de executar a ação')
//        })
//    })
//});
//

//$(document).ready(function(){
//    $('.button4').click(function(){
//        $('.button10').hide('slow', function(){
//            alert('terminou de esconder')
//        });
//    })
//    $('.button5').click(function(){
//        $('.button10').show(2000, function (){
//            alert('terminou de mostrar')
//        });
//    })
//})

    

//$('.button10').fadeOut("2000").fadeIn("2000");
//$('.button10').remove();
//$('.button10').append(" legal");

$('.button10').on("click", botao);
function botao(){
    $('.button10').css({'color':'yellow'})
}

$('#teste').html("teste");

$('p').addClass('');

$(document).ready(function(){

});



