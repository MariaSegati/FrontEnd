$(document).ready(function(){
function cadastrar(){
var nome = document.getElementById('nome').value;
var cpf = document.getElementById('cpf').value;
var email = document.getElementById('email').value;
var endereco = document.getElementById('endereco').value;
var senha = document.getElementById('senha').value;
var errorMessage = document.getElementById('msg');
var errorMessage2 = document.getElementById('msg2');
var errorMessage3 = document.getElementById('msg3');
var errorMessage4 = document.getElementById('msg4');
var errorMessage5 = document.getElementById('msg5');

 if(nome == '' && cpf == '' && email  == '' && endereco == '' && senha == ''){
  errorMessage.textContent = "nome não preenchido!"
  errorMessage.classList = 'error';
  errorMessage2.textContent = "cpf não preenchido!"
  errorMessage2.classList = 'error';
  errorMessage3.textContent = "email não preenchido!"
  errorMessage3.classList = 'error';
  errorMessage4.textContent = "endereco não preenchido!"
  errorMessage4.classList = 'error';
  errorMessage5.textContent = "senha não preenchida!"
  errorMessage5.classList = 'error';
  return;
}
if(nome == ''){
  errorMessage.textContent = "nome não preenchido";
  errorMessage.classList = 'error';
}
if(cpf == ''){
  errorMessage2.textContent = "cpf não preenchido";
  errorMessage2.classList = 'error';
}
if(email == ''){
  errorMessage3.textContent = "e-mail não preenchido";
  errorMessage3.classList = 'error';
}
if(endereco == ''){
  errorMessage4.textContent = "endereço não preenchido";
  errorMessage4.classList = 'error';
}
if(senha == ''){
  errorMessage5.textContent = "senha não preenchida";
  errorMessage5.classList = 'error';
}

}
});

var errorMessage6 = document.getElementById('msg2');


let value_cpf = document.querySelector('#cpf');

 value_cpf.addEventListener("keydown", function(e) {
   if (e.key > "a" && e.key < "z") {
     e.preventDefault();
   }
 });
value_cpf.addEventListener("blur", function(e) {

     let validar_cpf = this.value.replace( /\D/g , "");


     if (validar_cpf.length==11){


      var Soma;
      var Resto;

      Soma = 0;
      for (i=1; i<=9; i++) Soma = Soma + parseInt(validar_cpf.substring(i-1, i)) * (11 - i);
         Resto = (Soma * 10) % 11;

      if ((Resto == 10) || (Resto == 11))  Resto = 0;
      if (Resto != parseInt(validar_cpf.substring(9, 10)) ) 
      return  errorMessage6.textContent = "cpf inválido!" 
      errorMessage6.classList = 'error';;

      Soma = 0;
      for (i = 1; i <= 10; i++) Soma = Soma + parseInt(validar_cpf.substring(i-1, i)) * (12 - i);
      Resto = (Soma * 10) % 11;

      if ((Resto == 10) || (Resto == 11))  Resto = 0;
      if (Resto != parseInt(validar_cpf.substring(10, 11) ) ) 
      return errorMessage6.textContent = "cpf invalido!" 
      errorMessage6.classList = 'error';;

      cpf_final = validar_cpf.replace( /(\d{3})(\d)/ , "$1.$2");
      cpf_final = cpf_final.replace( /(\d{3})(\d)/ , "$1.$2");
      cpf_final = cpf_final.replace(/(\d{3})(\d{1,2})$/ , "$1-$2");
      document.getElementById('campo_cpf').value = cpf_final;

     } else {
      errorMessage6.textContent = "cpf inválido, digite 11 digitos!" 
      errorMessage6.classList = 'error';;
     }   

 })









