document.getElementById(nome).textContent;
function sla(nome){
    for(var i=1;i<=2;i++){
    nome.innerHTML += localStorage.getItem('nome'+i);
    }
}