//Criar as funções para manipular o carrinho (adicionar, remover, confirmar)
window.onload = function carrinho(){
    var carrinho = document.getElementById('carrinho');
    exibirCarrinho(carrinho);
}
function addCarrinho(nome, preco, quantidade, posicao){ //parâmetros
    //localStorage (armazenamento do navegador)
    //não é adequado para senhas (não é seguro)
    //localStorage = permanente
    //sessionStorage = válido por uma sessão
    localStorage.setItem("nome"+posicao, nome); // chave: nome1: valor: Macarrão
    localStorage.setItem("preco"+posicao, preco); // chave: preco1: 1,99   
    localStorage.setItem("quantidade"+posicao, quantidade);
    console.log(nome);
}
function exibirCarrinho(carrinho){
    //Ler os dados do localStorage.getItem("nome"+posicao) -> for(repetição)
    //Mostrar os dados dos produtos na página carrinho.html
    //for() -> repetir para todos os itens do localStorage
    for(var i = 1; i <= 100; i++){
        if(localStorage.getItem('nome' + i) != null){ //produto foi add no carrinho
            carrinho.innerHTML = "<table><hr>......."+localStorage.getItem('nome' + i)+ //nome1 == null
            "<hr>..............."+localStorage.getItem('preco' + i)+
            "..................."+localStorage.getItem('quantidade' + i);
            //criar um botao para excluir item do carrinho
            //calcular valor total do carrinho
        
    }
    //exibir o valor total do carrinho
}  //listou todos os produtos
  // mostrou o valor total, porcentual de desconto, pagamento...
}
function excluirItem(item){
    //elaborar lógica p excluir item
//ao exibir o carrinho, devera ser criado um botao para chamar a funcao excluirItem()
//1- localizar item a ser exlcuido
//2- chamar a funcao para excluir o item do localstorage

}